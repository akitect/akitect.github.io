<?php
/*
Plugin Name: Lunch for HHOMM's Themes
Plugin URI: http://www.hhomm.com/
Version: 0.8.2
Author: Hyun-Gu Kim
Description: 디자인홈(HHOMM) 테마를 위한 워드프레스 관리자 패키지
*/


/* ACF 설치 */

// customize ACF path
add_filter('acf/settings/path', 'HHOMM_acf_settings_path');
function HHOMM_acf_settings_path( $path ) {
    // update path
    $path = plugin_dir_path( __FILE__ ) . 'include/acf/';
    // return
    return $path;
}

// customize ACF dir
add_filter('acf/settings/dir', 'HHOMM_acf_settings_dir');
function HHOMM_acf_settings_dir( $dir ) {
    // update path
    $dir = plugin_dir_url( __FILE__ ) . 'include/acf/';
    // return
    return $dir;
}

// Hide ACF field group menu item
add_filter('acf/settings/show_admin', 'HHOMM_acf_show_admin');
function HHOMM_acf_show_admin( $show ) {
    global $current_user;
    return $current_user->user_email == 'office@hhomm.com' ? true : false;
}

// Include ACF
include_once( 'include/acf/acf.php' );

// ACF 설정 불러오기
include_once( 'include/acf/hhomm-set.php' );

// HHOMM 개발자 설정에서 사이트 형식을 '단일페이지'로 선택한 경우 활성화
if ( get_field('service', 'option') == 'stand-alone' && get_field('site_type','option') == 'single' ) include_once( 'include/acf/page-set.php' ); 

// ACF option page 설정
if( function_exists('acf_add_options_page') ) {
  acf_add_options_page( array(
    'page_title' => 'HHOMM 관리자',
    'menu_title' => 'HHOMM 관리자',
    'menu_slug'  => 'hhomm-pack',
    'icon_url'   => 'dashicons-clipboard'
  ));
  acf_add_options_sub_page( array(
    'page_title' => '기본 설정',
    'menu_title' => '기본 설정',
    'menu_slug'  => 'basic-settings',
    'parent_slug'=> 'hhomm-pack'
  ));
  acf_add_options_sub_page( array(
    'page_title' => '개발자 설정',
    'menu_title' => '개발자 설정',
    'menu_slug'  => 'developer-options',
    'parent_slug'=> 'hhomm-pack'
  ));
}


if ( get_field('block','option') ) { // HHOMM 개발자 설정에서 블록 활성화시

  /* 블록 설정 */
  function hhomm_block_category( $categories, $post ) {
    return array_merge(
      $categories,
      array(
        array(
          'slug' => 'hhomm-blocks',
          'title' => __( 'HHOMM 블록', 'hhomm-1p-blocks' ),
        ),
      )
    );
  }
  add_filter( 'block_categories', 'hhomm_block_category', 10, 2);


  add_action('acf/init', 'hhomm_page_acf_init');
  function hhomm_page_acf_init() {

    // check function exists
    if( function_exists('acf_register_block') ) {

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-intro',
          'title'				  => __('도입'),
          'description'		=> __('Intro Block For 1P HHOMM'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/intro.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/intro.js',
          'post_types'    => array('page'),
          'icon'				  => '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="cocktail" class="svg-inline--fa fa-cocktail fa-w-18" role="img" viewBox="0 0 576 512"><path fill="currentColor" d="M296 464h-56V338.78l168.74-168.73c15.52-15.52 4.53-42.05-17.42-42.05H24.68c-21.95 0-32.94 26.53-17.42 42.05L176 338.78V464h-56c-22.09 0-40 17.91-40 40 0 4.42 3.58 8 8 8h240c4.42 0 8-3.58 8-8 0-22.09-17.91-40-40-40zM432 0c-62.61 0-115.35 40.2-135.18 96h52.54c16.65-28.55 47.27-48 82.64-48 52.93 0 96 43.06 96 96s-43.07 96-96 96c-14.04 0-27.29-3.2-39.32-8.64l-35.26 35.26C379.23 279.92 404.59 288 432 288c79.53 0 144-64.47 144-144S511.53 0 432 0z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-about',
          'title'				  => __('소개'),
          'description'		=> __('About Block For 1P HHOMM'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/about.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/about.js',
          'post_types'    => array('page'),
          'icon'				  => '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="pen-fancy" class="svg-inline--fa fa-pen-fancy fa-w-16" role="img" viewBox="0 0 512 512"><path fill="currentColor" d="M79.18 282.94a32.005 32.005 0 0 0-20.24 20.24L0 480l4.69 4.69 92.89-92.89c-.66-2.56-1.57-5.03-1.57-7.8 0-17.67 14.33-32 32-32s32 14.33 32 32-14.33 32-32 32c-2.77 0-5.24-.91-7.8-1.57l-92.89 92.89L32 512l176.82-58.94a31.983 31.983 0 0 0 20.24-20.24l33.07-84.07-98.88-98.88-84.07 33.07zM369.25 28.32L186.14 227.81l97.85 97.85 199.49-183.11C568.4 67.48 443.73-55.94 369.25 28.32z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-download',
          'title'				  => __('파일 다운로드'),
          'description'		=> __('Download Block For 1P HHOMM'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/download.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/download.js',
          'post_types'    => array('page'),
          'icon'				  => '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="file-download" class="svg-inline--fa fa-file-download fa-w-12" role="img" viewBox="0 0 384 512"><path fill="currentColor" d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm76.45 211.36l-96.42 95.7c-6.65 6.61-17.39 6.61-24.04 0l-96.42-95.7C73.42 337.29 80.54 320 94.82 320H160v-80c0-8.84 7.16-16 16-16h32c8.84 0 16 7.16 16 16v80h65.18c14.28 0 21.4 17.29 11.27 27.36zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'			  	=> 'hhomm-1p-tabs',
          'title'			  	=> __('다중 콘텐츠'),
          'description'		=> __('Tabs Block For 1P HHOMM'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/tabs.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/tabs.js',
          'post_types'    => array('page'),
          'icon'			  	=> '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="columns" class="svg-inline--fa fa-columns fa-w-16" role="img" viewBox="0 0 512 512"><path fill="currentColor" d="M464 32H48C21.49 32 0 53.49 0 80v352c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V80c0-26.51-21.49-48-48-48zM224 416H64V160h160v256zm224 0H288V160h160v256z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-contact',
          'title'				  => __('연락하기'),
          'description'		=> __('Contact Block For 1P HHOMM'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/contact.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/contact.js',
          'post_types'    => array('page'),
          'multiple'      => false,
          'icon'			  	=> '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="envelope-open-text" class="svg-inline--fa fa-envelope-open-text fa-w-16" role="img" viewBox="0 0 512 512"><path fill="currentColor" d="M176 216h160c8.84 0 16-7.16 16-16v-16c0-8.84-7.16-16-16-16H176c-8.84 0-16 7.16-16 16v16c0 8.84 7.16 16 16 16zm-16 80c0 8.84 7.16 16 16 16h160c8.84 0 16-7.16 16-16v-16c0-8.84-7.16-16-16-16H176c-8.84 0-16 7.16-16 16v16zm96 121.13c-16.42 0-32.84-5.06-46.86-15.19L0 250.86V464c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V250.86L302.86 401.94c-14.02 10.12-30.44 15.19-46.86 15.19zm237.61-254.18c-8.85-6.94-17.24-13.47-29.61-22.81V96c0-26.51-21.49-48-48-48h-77.55c-3.04-2.2-5.87-4.26-9.04-6.56C312.6 29.17 279.2-.35 256 0c-23.2-.35-56.59 29.17-73.41 41.44-3.17 2.3-6 4.36-9.04 6.56H96c-26.51 0-48 21.49-48 48v44.14c-12.37 9.33-20.76 15.87-29.61 22.81A47.995 47.995 0 0 0 0 200.72v10.65l96 69.35V96h320v184.72l96-69.35v-10.65c0-14.74-6.78-28.67-18.39-37.77z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-posts',
          'title'				  => __('색인 불러오기'),
          'description'		=> __('Posts Block For 1P HHOMM'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/posts.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/posts.js',
          'post_types'    => array('page'),
          'icon'				  => '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="rss" class="svg-inline--fa fa-rss fa-w-14" role="img" viewBox="0 0 448 512"><path fill="currentColor" d="M128.081 415.959c0 35.369-28.672 64.041-64.041 64.041S0 451.328 0 415.959s28.672-64.041 64.041-64.041 64.04 28.673 64.04 64.041zm175.66 47.25c-8.354-154.6-132.185-278.587-286.95-286.95C7.656 175.765 0 183.105 0 192.253v48.069c0 8.415 6.49 15.472 14.887 16.018 111.832 7.284 201.473 96.702 208.772 208.772.547 8.397 7.604 14.887 16.018 14.887h48.069c9.149.001 16.489-7.655 15.995-16.79zm144.249.288C439.596 229.677 251.465 40.445 16.503 32.01 7.473 31.686 0 38.981 0 48.016v48.068c0 8.625 6.835 15.645 15.453 15.999 191.179 7.839 344.627 161.316 352.465 352.465.353 8.618 7.373 15.453 15.999 15.453h48.068c9.034-.001 16.329-7.474 16.005-16.504z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-concept',
          'title'				  => __('컨셉 슬라이더'),
          'description'		=> __('Concept Block For HHOMM themes'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/concept.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/concept.js',
          'post_types'    => array('page'),
          'icon'			  	=> 'images-alt2',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-feature',
          'title'				  => __('표제 슬라이더'),
          'description'		=> __('Feature Block For HHOMM themes'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/feature.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/feature.js',
          'post_types'    => array('page'),
          'icon'			  	=> '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="far" data-icon="sticky-note" class="svg-inline--fa fa-sticky-note fa-w-14" role="img" viewBox="0 0 448 512"><path fill="currentColor" d="M448 348.106V80c0-26.51-21.49-48-48-48H48C21.49 32 0 53.49 0 80v351.988c0 26.51 21.49 48 48 48h268.118a48 48 0 0 0 33.941-14.059l83.882-83.882A48 48 0 0 0 448 348.106zm-128 80v-76.118h76.118L320 428.106zM400 80v223.988H296c-13.255 0-24 10.745-24 24v104H48V80h352z"/></svg>',
        )
      );

      acf_register_block(
        array(
          'name'				  => 'hhomm-1p-random',
          'title'				  => __('랜덤 포스트'),
          'description'		=> __('Random Block For HHOMM themes'),
          'render_callback'	=> 'hhomm_acf_block_render_callback',
          'category'			=> 'hhomm-blocks',
          'enqueue_style' => plugin_dir_url( __FILE__ ) .'block/css/random.css',
          'enqueue_script'=> plugin_dir_url( __FILE__ ) .'block/js/random.js',
          'post_types'    => array('page'),
          'icon'			  	=> '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="random" class="svg-inline--fa fa-random fa-w-16" role="img" viewBox="0 0 512 512"><path fill="currentColor" d="M504.971 359.029c9.373 9.373 9.373 24.569 0 33.941l-80 79.984c-15.01 15.01-40.971 4.49-40.971-16.971V416h-58.785a12.004 12.004 0 0 1-8.773-3.812l-70.556-75.596 53.333-57.143L352 336h32v-39.981c0-21.438 25.943-31.998 40.971-16.971l80 79.981zM12 176h84l52.781 56.551 53.333-57.143-70.556-75.596A11.999 11.999 0 0 0 122.785 96H12c-6.627 0-12 5.373-12 12v56c0 6.627 5.373 12 12 12zm372 0v39.984c0 21.46 25.961 31.98 40.971 16.971l80-79.984c9.373-9.373 9.373-24.569 0-33.941l-80-79.981C409.943 24.021 384 34.582 384 56.019V96h-58.785a12.004 12.004 0 0 0-8.773 3.812L96 336H12c-6.627 0-12 5.373-12 12v56c0 6.627 5.373 12 12 12h110.785c3.326 0 6.503-1.381 8.773-3.812L352 176h32z"/></svg>',
        )
      );

    }
    
  }

  function hhomm_acf_block_render_callback( $block ) {
    
    // convert name ("acf/testimonial") into path friendly slug ("testimonial")
    $slug = str_replace('acf/', '', $block['name']);
    $slug = str_replace('-1p-', '-', $slug);
    
    // include a template part from within the "template-parts/block" folder
    if( file_exists( plugin_dir_path( __FILE__ ) . 'block/'. $slug .'.php' ) ) {
      include( 'block/'. $slug .'.php' );
    }
      
  }

}

// 블록 acf 설정 불러오기 
if ( get_field('service', 'option') == 'stand-alone' ) include_once( 'block/acf-block-set.php' );

// Google Map api key 적용
add_filter('acf/settings/google_api_key', function () {
    return 'AIzaSyAIbu0SC40cVQImJmD--KrfsfZfAZXU5ZM';
});


/* 관리자 메뉴 라벨 사용자화 */
add_action( 'admin_menu', 'HHOMM_menu_label' );
function HHOMM_menu_label() {
  $post_label     = get_field('post_label','option');
  $page_label     = get_field('page_label','option');
  $media_label    = get_field('media_label','option');
  $portfolio_label= get_field('jetpack-portfolio_label','option');
  $dashboard_label= get_field('dashboard_label','option');
  $comment_label  = get_field('comment_label', 'option');

  global $menu;
  global $submenu;

  // posts 수정
  if ( $post_label ) {
    $menu[5][0] = $post_label;
    // $submenu['edit.php'][5][0] = $post_label;
    // $submenu['edit.php'][10][0] = $post_label .' 추가';
  }

  // media 수정
  if ( $media_label ) {
    $menu[10][0] = $media_label;
    $submenu['upload.php'][10][0] = $media_label;
    $submenu['media-new.php'][10][0] = $media_label .' 추가';
  }

  // pages 수정
  if ( $page_label ) {
    $menu[20][0] = $page_label;
  }

  // jetpack-portfolio 수정
  if ( $portfolio_label ) {
    $menu[21][0] = $portfolio_label;
    $submenu['edit.php?post_type=jetpack-portfolio'][5][0] = '모든 '.$portfolio_label;
    $submenu['edit.php?post_type=jetpack-portfolio'][10][0] = $portfolio_label .' 추가';
  }
  
  // dashboard 수정
  if ( $dashboard_label ) {
    $menu[2][0] = $dashboard_label;
  }

  // comments 수정
  if ( $comment_label ) {
    $menu[25][0] = $comment_label;
  }

}


/* 다른 사용자의 미디어 숨기기 */
add_filter( 'posts_where', 'hide_attachments_wpquery_where' );
function hide_attachments_wpquery_where( $where ){
	global $current_user;
	if( !current_user_can( 'manage_options' ) ) {
		if( is_user_logged_in() ){
			if( isset( $_POST['action'] ) ){
				// library query
				if( $_POST['action'] == 'query-attachments' ){
					$where .= ' AND post_author='.$current_user->data->ID;
				}
			}
		}
	}

	return $where;
}


/* 미디어파일 업로드시 파일명 재설정 */
if ( is_admin() ) {

    add_filter('sanitize_file_name', 'make_filename_hash', 10);
    function make_filename_hash($filename) {

        $post_id = $_REQUEST['post_id'];
  
        $file = pathinfo($filename);
        $extention = $file['extension'];
        $name = basename($filename, $extention);
  
        if( isset($post_id) && $post_id ){
  
            $post_type  = get_post_type($post_id);
  
            /* 마지막 이미지 파일명 확인 */
            $attached_array = get_posts( array(
                'post_type' => 'attachment',
                'post_parent' => $post_id,
                'posts_per_page' => -1,
                'post_mime_type' => 'image'
            ) );
  
            $attached_no = count($attached_array) + 1;
            $file_no = $post_id . str_pad($attached_no, 3, '0', STR_PAD_LEFT);
  
            return $post_type .'-'. $file_no .'.'. $extention;
  
        } else {
            return $name .'.'. $extention;
        }
  
    }
  
}

/* 사용자 author 포스트 발행 금지 */
add_action( 'init', 'customize_author_roles' );
function customize_author_roles() {
	// get_role returns an instance of WP_Role.
  $role = get_role( 'author' );
  $role->remove_cap( 'edit_posts' ); // post 차단
	$role->add_cap( 'publish_pages' );
	$role->add_cap( 'edit_pages' );
	$role->add_cap( 'edit_published_pages' );
	$role->add_cap( 'edit_private_pages' );
	$role->add_cap( 'read_private_pages' );
}


/* 관리자 페이지 라벨 수정 */
if ( get_field('service', 'option') == 'membership' ) add_filter('register_post_type_args', 'custom_post_ui', 10, 2);
function custom_post_ui($args, $post_type){

    if ($post_type == 'page'){
      $args['public'] = true;
      $args['show_ui'] = true;
      $args['label'] = '사이트';
      $args['labels']['name'] = '사이트';
      $args['labels']['singular_name'] = '사이트';
      $args['labels']['edit_item'] = '사이트 편집';
      $args['labels']['add_new'] = '사이트 등록';
      $args['labels']['add_new_item'] = '사이트 등록';
      $args['labels']['view_item'] = '사이트 보기';
      $args['labels']['view_items'] = '사이트 보기';
      $args['labels']['search_items'] = '사이트 검색';
    }

    return $args;
}

add_action ( 'init', 'customize_admin_labels');
function customize_admin_labels () {

  global $wp_post_types;

  $items = array( 'post', 'page');

  $post_types = array();
  foreach( $items as $item ) {
    ${ $item .'_label' } = get_field($item .'_label', 'option');
    if ( ${ $item .'_label' } ) { array_push( $post_types, $item ); }
  }
  
  foreach ( $post_types as $item ){
    $labels = $wp_post_types[$item]->labels;
    
    $labels->name = ${ $item .'_label' };
    $labels->all_items = '모든 '. ${ $item .'_label' };
    $labels->singular_name = ${ $item .'_label' };
    $labels->add_new = '새 '. ${ $item .'_label' } . ' 추가';
    $labels->add_new_item = ${ $item .'_label' } . ' 추가';
    $labels->edit_item = ${ $item .'_label' } . ' 편집';
    $labels->new_item = '새 '. ${ $item .'_label' };
    $labels->view_item = ${ $item .'_label' } .' 보기';
    $labels->search_items = ${ $item .'_label' } .' 검색';
  }
  
}


add_action( 'right_now_content_table_end' , 'wph_right_now_content_table_end' );
function wph_right_now_content_table_end() {
  $args = array(
    'public' => true ,
    '_builtin' => false
  );
  $output = 'object';
  $operator = 'and';
  $post_types = get_post_types( $args , $output , $operator );
  foreach( $post_types as $post_type ) {
    $num_posts = wp_count_posts( $post_type->name );
    $num = number_format_i18n( $num_posts->publish );
    $text = _n( $post_type->labels->singular_name, $post_type->labels->name , intval( $num_posts->publish ) );
    if ( current_user_can( 'edit_posts' ) ) {
      $num = "<a href='edit.php?post_type=$post_type->name'>$num</a>";
      $text = "<a href='edit.php?post_type=$post_type->name'>$text</a>";
    }
    echo '<tr><td class="first b b-' . $post_type->name . '">' . $num . '</td>';
    echo '<td class="t ' . $post_type->name . '">' . $text . '</td></tr>';
  }
  $taxonomies = get_taxonomies( $args , $output , $operator );
  foreach( $taxonomies as $taxonomy ) {
    $num_terms  = wp_count_terms( $taxonomy->name );
    $num = number_format_i18n( $num_terms );
    $text = _n( $taxonomy->labels->singular_name, $taxonomy->labels->name , intval( $num_terms ));
    if ( current_user_can( 'manage_categories' ) ) {
      $num = "<a href='edit-tags.php?taxonomy=$taxonomy->name'>$num</a>";
      $text = "<a href='edit-tags.php?taxonomy=$taxonomy->name'>$text</a>";
    }
    echo '<tr><td class="first b b-' . $taxonomy->name . '">' . $num . '</td>';
    echo '<td class="t ' . $taxonomy->name . '">' . $text . '</td></tr>';
  }
}


/* 프론트엔드 스크립트 활성화 */
add_action('wp_enqueue_scripts', 'HHOMM_frontend_scripts', 99);
function HHOMM_frontend_scripts() {

  wp_enqueue_script( 'front-end', plugin_dir_url( __FILE__ ) . 'front-end/front-end.js');
  wp_enqueue_style ( 'front-end', plugin_dir_url( __FILE__ ) . 'front-end/front-end.css');

  wp_enqueue_script( 'google-maps-api', 'https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyAIbu0SC40cVQImJmD--KrfsfZfAZXU5ZM' );
	wp_enqueue_script( 'acf-google-maps', plugin_dir_url( __FILE__ ) . 'include/googlemaps.js');

  // webfont
  wp_enqueue_style ( 'font-nanum', plugin_dir_url( __FILE__ ) . 'font/NanumFonts.css');
  wp_enqueue_style ( 'font-agane', plugin_dir_url( __FILE__ ) . 'font/Agane.css');
  wp_enqueue_style ( 'font-iropke', plugin_dir_url( __FILE__ ) . 'font/Iropke.css');
  wp_enqueue_style ( 'font-notosans', plugin_dir_url( __FILE__ ) . 'font/NotoSans.css');

  // font awesome
  if ( get_field('font_awesome', 'option') ) {
    wp_enqueue_style ( 'font-awesome', plugin_dir_url( __FILE__ ) . 'include/font-awesome/all.min.css');
  }
  // swiper
  if ( get_field('swiper', 'option') ) {
    wp_enqueue_style ( 'swiper', plugin_dir_url( __FILE__ ) . 'include/swiper/swiper.min.css');
    wp_enqueue_script( 'swiper', plugin_dir_url( __FILE__ ) . 'include/swiper/swiper.min.js');
  }

  /* Custom CSS 적용 */
  $custom_css = get_field('custom_css', 'option');
  if ( $custom_css ) {
    wp_add_inline_style( 'front-end', $custom_css );
  }

}


/* Admin Bar 숨기기 */
add_filter( 'show_admin_bar', '__return_false' );

/* HHOMM 관리자 설정 */
function HHOMM_admin_script_enqueue() {
  wp_enqueue_style( 'admin-css', plugin_dir_url( __FILE__ ) . 'admin/admin.css');
  wp_enqueue_script( 'admin-js', plugin_dir_url( __FILE__ ) . 'admin/admin.js');
  // font awesome
  if ( get_field('font_awesome', 'option') ) {
    wp_enqueue_style ( 'font-awesome', plugin_dir_url( __FILE__ ) . 'include/font-awesome/all.min.css');
  }
  // swiper
  if ( get_field('swiper', 'option') ) {
    wp_enqueue_style ( 'swiper', plugin_dir_url( __FILE__ ) . 'include/swiper/swiper.min.css');
    wp_enqueue_script( 'swiper', plugin_dir_url( __FILE__ ) . 'include/swiper/swiper.min.js');
  }
}
add_action('admin_enqueue_scripts', 'HHOMM_admin_script_enqueue');


/* HHOMM 개발자를 위한 Admin body 클래스 추가 */
add_filter( 'admin_body_class', 'hhomm_admin_body_class' );
function hhomm_admin_body_class( $classes ) {
  global $current_user;
  if ( $current_user->user_email == 'office@hhomm.com' )
    $classes .= ' HHOMM-developer ';

  if ( get_field('adminbar', 'option') )
    $classes .= 'hidden-adminbar ';
  return $classes;
}


/* body class에 추가 */
add_filter( 'body_class','hhomm_body_classes' );
function hhomm_body_classes( $classes ) {
    
    $visibility = get_field('visibility', 'option');

    switch ( $visibility ) {

      case 'developer-only' : 

        global $current_user;
        $classes[] .= $current_user->user_email == 'office@hhomm.com' ? '' : 'parking parking-' . str_pad(rand(0,9), '2', '0', STR_PAD_LEFT);
        
        break;

      case 'user-only' :
        
        $classes[] .= is_user_logged_in() ? '' : 'parking parking-' . str_pad(rand(0,9), '2', '0', STR_PAD_LEFT);

        break;

      case 'public' :
      
        break;
    }
     
    return $classes;    
}


/* 불펌 경고 */
add_action('wp_enqueue_scripts', 'piracy_warning');
function piracy_warning() {
  $piracy_warning = get_field('piracy_warning', 'option');
  $warning_message = trim(preg_replace('/\s\s+/', '-!!-', $piracy_warning));
  if ( $piracy_warning ) {
    echo '<script type="text/javascript">
          document.addEventListener("copy", function (e) {
            alert("'. str_replace('-!!-', '\n', $warning_message) .'");
          });
          document.addEventListener("contextmenu", function(e) {
            alert("'. str_replace('-!!-', '\n', $warning_message) .'");
          });
          </script>';
  }
}


/* HHOMM Dashboard 모드 설정 */
add_action( 'admin_menu', 'HHOMM_menus' );
function HHOMM_menus() {
  if ( get_field('admin_mode', 'option') == 'basic-mode') {
    $hidden_menus = get_field('hidden_menus', 'option');
    if ( $hidden_menus ) {
      foreach ( $hidden_menus as $hidden_menu ) {
        remove_menu_page( $hidden_menu );
        // remove_menu_page( 'index.php' );                  //Dashboard
        // remove_menu_page( 'edit.php' );                   //Posts
        // remove_menu_page( 'upload.php' );                 //Media
        // remove_menu_page( 'edit.php?post_type=page' );    //Pages
        // remove_menu_page( 'edit-comments.php' );          //Comments
        // remove_menu_page( 'themes.php' );                 //Appearance
        // remove_menu_page( 'plugins.php' );                //Plugins
        // remove_menu_page( 'users.php' );                  //Users
        // remove_menu_page( 'tools.php' );                  //Tools
        // remove_menu_page( 'options-general.php' );        //Settings
      }
    }
    $add_menus = get_field('add_menus', 'option');
    if ( $add_menus ) {
      foreach ( $add_menus as $new_menu ) {
        $capability = $new_menu['type'] == 'post' ? 'edit_posts' : $new_menu['capability'];
        $slug = $new_menu['type'] == 'post' ? 'post.php?post='. $new_menu['post_id'] .'&action=edit' : $new_menu['slug'];
        add_menu_page(
          $new_menu['title'],
          $new_menu['title'],
          $capability,
          $slug,
          '',
          $new_menu['icon'],
          $new_menu['position']
        );
      }
      // 추가한 메뉴 선택시 highlight 적용
      add_filter('parent_file', 'highlight_admin_menu');
      function highlight_admin_menu($some_slug){
        global $parent_file;
        $parent_file = explode( 'wp-admin/', $_SERVER[REQUEST_URI])[1];
        return $parent_file;
      }
    }

    /* Dashboard 디자인 */
    $remove_items = get_field('remove_items', 'option');
    if ( isset($remove_items) && $remove_items ) {
      if ( in_array( 'screen-options', $remove_items) ) {
        // 도움말 숨기기
        add_filter( 'contextual_help', 'mytheme_remove_help_tabs', 999, 3 );
        function mytheme_remove_help_tabs($old_help, $screen_id, $screen){
            $screen->remove_help_tabs();
            return $old_help;
        }
      }
      if ( in_array( 'help', $remove_items) ) {
        // 화면 옵션 숨기기
        add_filter('screen_options_show_screen', '__return_false');
      }
      if ( in_array( 'wpfooter', $remove_items) ) {
        // 하단 wpfooter 와 버전 숨기기
        add_filter( 'update_footer',     '__return_empty_string', 11 );
        add_filter( 'admin_footer_text', '__return_empty_string', 11 );
      }
    }
  }
}

/* 로그인 로고 설정 */
add_action('login_head', 'custom_loginlogo');
function custom_loginlogo() {
  $login_logo = get_field('login_logo', 'option') ? get_field('login_logo', 'option'): plugin_dir_url( __FILE__ ) .'img/HHOMM_logo.svg';
  $login_logo_height = get_field('login_logo_height', 'option') ? get_field('login_logo_height', 'option') : 60;
  $login_bg_color = get_field('login_bg_color', 'option') ? get_field('login_bg_color', 'option') : '#0073aa';
  echo '<style type="text/css">
          body { background-color: '. $login_bg_color .';}
          .login h1 a {
            background-image: none, url('. $login_logo .') !important;
            background-size: contain;
          	width: 100%;
            height: '. $login_logo_height .'px;
            color
          }
          .login form { box-shadow: 5px 12px 80px rgba(0,0,0,0.35); }
          .login #backtoblog a, .login #nav a { color: #fff; }
        </style>';
}

add_filter( 'login_headerurl', 'custom_login_logo_url' );
function custom_login_logo_url() {
  return get_bloginfo( 'url' );
}

add_filter( 'login_headertitle', 'custom_login_logo_url_title' );
function custom_login_logo_url_title() {
  return get_bloginfo( 'name' );
}

/* 업데이트 설정 */
require 'update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'http://hhomm.work/dev/@akitect/updates/lunch-for-hhomm.json',
  __FILE__,
  'lunch-for-hhomm'
);

/* 관리자에 아이콘 폰트 적용 */
add_action('acf/input/admin_head', 'custom_font_icons');
add_action('wp_head', 'custom_font_icons');
function custom_font_icons(){
	// flaticon 업데이트에 따른 조정
	global $wp_query;
	$postid = $wp_query->post->ID;
	$flaticon_code = '\f1';
	?>
	<style type="text/css">

		@font-face {
			font-family: "iconFont";
			font-weight: normal;
            font-style: normal;
			src: url("<?php the_field('eot', $postid); ?>");
			src: url("<?php the_field('eot', $postid); ?>#iefix") format("embedded-opentype"),
			url("<?php the_field('woff', $postid); ?>") format("woff"),
			url("<?php the_field('ttf', $postid); ?>") format("truetype"),
			url("<?php the_field('svg', $postid); ?>") format("svg");
		}
		[class^="iconfont-"], [class*=" iconfont-"],
		[class^="iconfont-"], [class*=" iconfont-"] {
            font-size: 24px;
		}
		[class^="iconfont-"]:before, [class*=" iconfont-"]:before,
		[class^="iconfont-"]:after, [class*=" iconfont-"]:after {
			font-family: "iconFont";
            font-style: normal;
			padding: 0.15em;
			display: inline-block;
		}
		.iconfont-000:before {
			content: "<?php echo $flaticon_code; ?>00";
		}
		.iconfont-001:before {
			content: "<?php echo $flaticon_code; ?>01";
		}
		.iconfont-002:before {
			content: "<?php echo $flaticon_code; ?>02";
		}
		.iconfont-003:before {
			content: "<?php echo $flaticon_code; ?>03";
		}
		.iconfont-004:before {
			content: "<?php echo $flaticon_code; ?>04";
		}
		.iconfont-005:before {
			content: "<?php echo $flaticon_code; ?>05";
		}

	</style>
	<?php
}


/* 기타파일 업로드 허용 */
add_filter('upload_mimes', 'custom_upload_mimes');
function custom_upload_mimes ( $mimes=array() ) {
  $mimes['hwp'] = 'application/hangul';
  $mimes['svg'] = 'image/svg+xml';
  $mimes['ttf'] = 'application/x-font-ttf';
  $mimes['woff']= 'application/x-font-woff';
  $mimes['eot'] = 'application/vnd.ms-fontobject';
  $mimes['zip'] = 'application/zip';
  $mimes['gz']  = 'application/x-gzip';
  return $mimes;
}


/* 업로드 용량 증가 */
@ini_set( 'upload_max_size' , '64M' );
@ini_set( 'post_max_size', '64M');
@ini_set( 'max_execution_time', '300' );


/* acf embeded to full screen iframe */
function fullscreen_video($iframe, $options) {
  // use preg_match to find iframe src
  preg_match('/src="(.+?)"/', $iframe, $matches);
  $src = $matches[1];

  preg_match('/youtube\.com\/embed\/(.+?)\?/', $src, $matches);
  $youtube_id = $matches[1];

  $options  = $options ? $options : array();
  $controls = in_array('controls', $options) ? 1 : 0;
  $loop     = in_array('loop', $options)     ? 1 : 0;
  $playlist = $loop ? $youtube_id : ''; // 반복재생시 playlist 파라메터 추가
  $showinfo = in_array('showinfo', $options) ? 1 : 0;
  $autoplay = in_array('autoplay', $options) ? 1 : 0;
  $mute     = $autoplay || in_array('mute', $options) ? 1 : 0;
  $color    = in_array('color', $options)    ? 'white' : 'red';
  // add extra params to iframe src
  $params = array(
      'controls'  => $controls,
      'hd'        => 1,
      'autohide'  => 1,
      'loop'      => $loop,
      'rel'       => 0,
      'showinfo'  => $showinfo,
      'autoplay'  => $autoplay,
      'modestbranding' => 1,
      'color'     => $color,
      'mute'      => $mute,
      'playlist'  => $playlist
  );

  $new_src = add_query_arg($params, $src);

  $iframe = str_replace($src, $new_src, $iframe);

  // add extra attributes to iframe html
  $play = $autoplay > 0 ? ' play' : '';
  $attributes = 'frameborder="0" allowfullscreen class="fullscreen'. $play .'" allow="autoplay;fullscreen"';

  $iframe = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $iframe);

  // return $iframe
  return $iframe;
}
