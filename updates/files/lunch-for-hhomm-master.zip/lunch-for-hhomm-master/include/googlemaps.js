(function($) {

/*
*  render_map
*
*  This function will render a Google Map onto the selected jQuery element
*
*  @type	function
*  @date	8/11/2013
*  @since	4.3.0
*
*  @param	$el (jQuery element)
*  @return	n/a
*/

function render_map( $el ) {

	var map_zoom = parseInt($('.acf-map').attr('data-zoom'));
	map_zoom = map_zoom ? map_zoom : 12;

	// var
	var $markers = $el.find('.marker');

	/* HHOMM 지도 옵션 설정 */
	// vars
	var args = {
		zoom		: map_zoom,
		center		: new google.maps.LatLng(0, 0),
		mapTypeId	: google.maps.MapTypeId.ROADMAP,
	};

	var all_option = new Array('disableDefaultUI','scrollwheel','zoomControl','mapTypeControl','streetViewControl','scaleControl');
	var options = $('.acf-map').attr('data-options') ? $('.acf-map').attr('data-options') : 'disableDefaultUI,zoomControl,scaleControl';
	var map_options  = '';

	$(all_option).each( function() {
		var option_value = options.indexOf(this) > -1 ? true : false;
		args[this] = option_value;
	});

	// create map
	var map = new google.maps.Map( $el[0], args);

	// add a markers reference
	map.markers = [];

	// add markers
	$markers.each(function(){

    	add_marker( $(this), map );

	});

	// center map
	center_map( map );



}

/*
*  add_marker
*
*  This function will add a marker to the selected Google Map
*
*  @type	function
*  @date	8/11/2013
*  @since	4.3.0
*
*  @param	$marker (jQuery element)
*  @param	map (Google Map object)
*  @return	n/a
*/


function add_marker( $marker, map ) {

	// var
	var latlng = new google.maps.LatLng( $marker.attr('data-lat'), $marker.attr('data-lng') );

	/*
	var markerIcon = {
		path: 'M-44 619 c-119 -54 -172 -168 -131 -283 21 -61 125 -224 185 -291 l36 -40 36 40 c60 67 164 230 185 291 65 185 -132 364 -311 283z m174 -78 c72 -40 98 -144 56 -219 -80 -143 -300 -85 -300 79 0 129 131 204 244 140z, M0 496 c-38 -17 -67 -74 -58 -113 4 -15 18 -40 32 -55 21 -23 34 -28 72 -28 38 0 51 5 72 28 14 15 28 40 32 55 10 41 -20 96 -60 113 -41 17 -50 17 -90 0z',
		fillColor: markerColor,
		fillOpacity: 1,
		scale: 0.12,
		strokeWeight: 0,
		rotation: 180,
		anchor: new google.maps.Point(56,70),
	};
	*/

	var markerSrc = $marker.attr('data-marker-src') ? $marker.attr('data-marker-src') : $('div.acf-map').attr('data-marker-src'); // 사용자 아이콘 불러오기
	var markerSize= $marker.attr('data-marker-size') ? Number($marker.attr('data-marker-size')) : Number($('div.acf-map').attr('data-marker-size'));
	var size = new google.maps.Size(markerSize, markerSize); // 마커 이미지 사이즈
	var image = {
		url: markerSrc,
		size: size,
		scaledSize: new google.maps.Size(markerSize, markerSize) // 적용 사이즈 (1/2)
	};

	// create marker
	if ( markerSrc ) {
		var marker = new google.maps.Marker({
			position	: latlng,
			map			: map,
			icon		: image
		});
	} else {
		var marker = new google.maps.Marker({
			position	: latlng,
			map			: map
		});
	}


	// add to array
	map.markers.push( marker );

	// if marker contains HTML, add it to an infoWindow
	if( $marker.html() )
	{
		// create info window
		var infowindow = new google.maps.InfoWindow({
			content		: $marker.html()
		});

		// show info window when marker is clicked
		google.maps.event.addListener(marker, 'click', function() {

			infowindow.open( map, marker );

		});
	}

	var styles = [{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"water","elementType":"geometry","stylers":[{"visibility":"on"},{"color":"#C6E2FF"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"color":"#C5E3BF"}]},{"featureType":"road","elementType":"geometry.fill","stylers":[{"color":"#D1D1B8"}]}]

	map.setOptions({styles: styles});

}

/*
*  center_map
*
*  This function will center the map, showing all markers attached to this map
*
*  @type	function
*  @date	8/11/2013
*  @since	4.3.0
*
*  @param	map (Google Map object)
*  @return	n/a
*/

function center_map( map ) {

	// vars
	var bounds = new google.maps.LatLngBounds();

	// loop through all markers and create bounds
	$.each( map.markers, function( i, marker ){

		var latlng = new google.maps.LatLng( marker.position.lat(), marker.position.lng() );

		bounds.extend( latlng );

	});

	// only 1 marker?
	if( map.markers.length == 1 ){

		var map_zoom = parseInt($('.acf-map').attr('data-zoom'));
		map_zoom = map_zoom ? map_zoom : 12;

		// set center of map
	    map.setCenter( bounds.getCenter() );
	    map.setZoom( map_zoom );

	} else {

		// fit to bounds
		map.fitBounds( bounds );

	}

}

/*
*  document ready
*
*  This function will render each map when the document is ready (page has loaded)
*
*  @type	function
*  @date	8/11/2013
*  @since	5.0.0
*
*  @param	n/a
*  @return	n/a
*/

$(document).ready(function(){

	$('.acf-map').each(function(){

		render_map( $(this) );
		$(this).addClass('roaded');

	});

}).ajaxComplete(function() { //ajax 부분에 대한 지도 렌더링 ( .sticky-map 제외 )

	$('.acf-map:not(.roaded)').each(function(){

		render_map( $(this) );
		$(this).addClass('roaded');

	});

});

})(jQuery);
