<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');
$bgimage   = get_field('bgimage');
$button_bg = $fontcolor == "#ffffff" ? 'button-bg-transparent' : '';
$style     = $bgimage ? 'style="color:'. $fontcolor .';background-image:url('. $bgimage['url'] .');"' : 'style="color:'. $fontcolor .';background-color:'. $bgcolor .';"';

$title   = get_field('title') ? get_field('title') : '';
$content = get_field('content') ? apply_filters('the_content', get_field('content', false, false)) : '';

$type        = get_field('type');
$map         = get_field('map');
$map_options = 'data-options="'. implode(get_field('map_options'), ',') .'"';
$marker_icon = get_field('marker_icon') ? 'data-marker-src="'. get_field('marker_icon') .'"' : '';
$marker_size = get_field('marker_size') ? 'data-marker-size="'. get_field('marker_size') .'"' : '';

$form  = get_field('form');
$label = get_field('label');
$label_fontcolor = get_field('label_fontcolor');
$label_bgcolor   = get_field('label_bgcolor');
$label_style = $label_fontcolor && $label_bgcolor ? 'style="background-color:'. $label_bgcolor .';color:'. $label_fontcolor .';"' : '';
$button    = strpos($form, 'http') !== false ? '<a href="'. $form .'" target="_blank" class="open-form-side" '. $label_style .'>'. get_field('label') .'</a>' : '<a href="#'. $id .'" target="_blank" class="open-form-side" '. $label_style .'>'. get_field('label') .'</a>';
$popupform = strpos($form, 'http') !== false ? '' : '<div id="popup-form"><div class="section-header"><i class=""></i>'. $label .'</div>'. do_shortcode($form) .'<div class="close"><i class="adminicon-cross"></i></div></div>';
?>

<div id="<?php echo $id; ?>" class="section contact <?php echo $button_bg .' '. $type; ?>" <?php echo $style; ?>>

    <div class="section-header">
        <span>
            <?php 
                $icon = get_page_template_slug() == false ? '<i class="'. get_field('icon') .'"></i>' : '';
                echo $icon . $title;
            ?>
        </span>
    </div>

    <?php include_once( 'contact-type/'. $type .'.php' ); ?>

</div>