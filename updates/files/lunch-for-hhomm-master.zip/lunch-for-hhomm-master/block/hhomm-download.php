<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');

$title     = get_field('title');
?>

<div id="<?php echo $id; ?>" class="section">
  <div class="card-content max-width-800">
    <h2><span><?php echo $title; ?></span></h2>
    <?php the_field('intro'); ?>

    <div class="menu-list">

      <?php
        $list = get_field('list');
        foreach( $list as $item ) {

          $title  = $item['label'];
          $status = $item['activate'] ? 'menu-content active' : 'menu-content';
          $password  = $item['password'] ? ' show-pw-input' : '';
          $form_data = $password ? 'data-id="'. $index .'" data-type="download"' : '';

          $file_list = '';
          $files = $item['files'];

          if ( $files ) {

            $file_list .= '<div class="files">';

            foreach( $files as $file ) {
              $file_list .= '<a href="'. $file['file']['url'] .'" title="'. $file['file']['title'] .'" download><i class="fa fa-file" aria-hidden="true"></i> '. $file['file']['title'] .'</a>';
            }

            $file_list .= '</div>';

          }

          $index++;

          echo '<div class="'. $status . $password .'" '. $form_data .'>
                  <h4>'. $title .'</h4>
                  '. $content . $file_list .'
                </div>';
        }
      ?>

    </div>
  </div>
</div>

<!-- style -->
<style type="text/css">
    #<?php echo $id; ?> {
        color:<?php echo $fontcolor; ?>;
        background-color:<?php echo $bgcolor; ?>; 
    }
    #<?php echo $id; ?> .card-content h2 {
        border-bottom: 4px solid <?php echo $fontcolor; ?>; 
    }
</style>