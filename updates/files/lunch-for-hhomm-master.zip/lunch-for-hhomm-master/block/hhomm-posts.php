<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');
$bgimage   = get_field('bgimage');
$button_bg = $fontcolor == "#ffffff" ? 'button-bg-transparent' : '';
$style     = $bgimage ? 'style="color:'. $fontcolor .';background-image:url('. $bgimage['url'] .');"' : 'style="color:'. $fontcolor .';background-color:'. $bgcolor .';"';

$title      = get_field('title') ? get_field('title') : '';
$content    = get_field('content') ? apply_filters('the_content', get_field('content', false, false)) : '';
$post_type  = get_field('connect'); // 불러올 포스트 타입
$type       = get_field('type');
$link_target= get_field('link_target');
$template   = $post_type == 'post' ? get_field('post_template') : get_field('project_template');
$posts_per_page = get_field('count');
?>

<div id="<?php echo $id; ?>" class="section post-index <?php echo $button_bg; ?>" <?php echo $style; ?>>
    <div class="section-header">
        <span>
            <?php 
                $icon = get_page_template_slug() == false ? '<i class="'. get_field('icon') .'"></i>' : '';
                echo $icon . $title;
            ?>
        </span>
    </div>
    <div class="content-wrap <?php echo $type; ?>">

        <?php include_once( 'index-type/'. $type .'.php' ); ?>

    </div>
</div>