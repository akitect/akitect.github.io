<?php

$posts_per_page = $posts_per_page > 0 ? $posts_per_page : -1;
$paged = get_query_var('page') ? get_query_var('page') : 1;

$connected_posts = get_posts(
    array(
    'posts_per_page'   => $posts_per_page,
    'orderby'          => 'date',
    'order'            => 'DESC',
    'post_type'        => $post_type,
    'paged'            => $paged,
    )
);

$post_length = count($connected_posts);

foreach( $connected_posts as $post ) {

    $thumb_url = get_the_post_thumbnail_url($post, $size='medium');
    $thumb_url = $thumb_url ? 'class="thumbnail" style="background-image:url('. $thumb_url .');"' : 'class="thumbnail no-thumbnail"';
    $date      = get_the_date('Y.m.d', $post);
    $title     = $post->post_title;
    $excerpt   = strip_tags(get_the_excerpt($post));
    $excerpt   = ltrim(preg_replace( '~^(\s*(?:&nbsp;)?)*~i', '', $excerpt));
    
    echo '<a class="post-wrap" href="'. get_the_permalink($post) .'" target="'. $link_target .'" data-id="id-'. $post->ID .'" data-template="'. $template .'">
            <div class="thumbnail-wrap">
                <div '. $thumb_url .'></div>
            </div>
            <div class="date"><i class="far fa-clock"></i> '. $date .'</div>
            <h2 class="title">'. $title .'</h2>
            <div class="excerpt">'. $excerpt .'</div>
          </a>';

}

if ( $posts_per_page > 0 && $post_length >= $posts_per_page ) {
    
    echo '<button class="load-more" data-page-no="'. ($paged + 1) .'" data-posts-per-page="'. $posts_per_page .'"></button>';

}
?>