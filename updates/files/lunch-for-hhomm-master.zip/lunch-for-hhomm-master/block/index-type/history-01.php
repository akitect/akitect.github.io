<?php

$connected_posts = get_posts(
    array(
    'numberposts'      => -1,
    'orderby'          => 'date',
    'order'            => 'DESC',
    'post_status'      => array('publish', 'pending', 'draft'),
    'post_type'        => $post_type,
    )
);

$post_length = count($connected_posts);
$count = 0;
$history_count = 0;
$posts_per_page = $posts_per_page > 0 ? $posts_per_page : 9999;
$open_set_length= get_field('open');
$open_set_length= $open_set_length > 0 ? $open_set_length : 9999;

foreach( $connected_posts as $post ) {

    $post_id = $post->ID;
    $current_year = date('Y');
    $year = get_the_date('Y', $post_id);
    
    if ( $year <= $current_year ) {

        $count++;

        if ( $prev_post_year && $prev_post_year != $year ) {

            $history_count++;
            $post_set_class = $history_count > $open_set_length ? 'post-set close' : 'post-set';
            $post_set_style = $history_count > $posts_per_page ? ' style="display:none;"' : '';
            
            echo '<div class="'. $post_set_class .'"'. $post_set_style .'>
                    <div class="label">'. $prev_post_year .'</div>
                    <ul class="post-list">'. $post_list .'</ul>
                  </div>';
            $post_list = '';
            
        }
    
   
        $post_list .= get_post_status($post_id) == 'publish' ? '<li><a href="'. get_the_permalink($post) .'" data-id="id-'. $post_id .'" target="'. $link_target .'" data-template="'. $template .'">'. $post->post_title .'</a></li>' : '<li>'. $post->post_title .'</li>';
        $prev_post_year = $year;
    
        // if ( $post_length == $count ) {
        //     echo '<div class="'. $post_set_class .'">
        //             <div class="label">'. $year .'</div>
        //             <ul class="post-list">'. $post_list .'</ul>
        //         </div>';
        // }

    }
    
}; 

/* load more 버튼 */
if ( $history_count > $posts_per_page ) {
    echo '<button class="load-more" data-page-no="all"></button>';
}

?>