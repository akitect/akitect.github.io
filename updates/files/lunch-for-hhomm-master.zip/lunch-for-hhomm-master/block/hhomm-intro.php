<?php 
$id = $block['id'];
$type = get_field('type');
$fontcolor = get_field('fontcolor');
$button_bg = $fontcolor == "#ffffff" ? 'button-bg-transparent' : '';
$align = $type == 'video' ? get_field('align') .'iframe-include' : get_field('align');

switch ( $type ) {

    case 'text':
        $bgcolor = get_field('bgcolor');
        $style   = 'style="color:'. $fontcolor .';background-color:'. $bgcolor .';"';
        $title   = get_field('title') ? '<h1>'. get_field('title') .'</h1>' : '';
        $content = get_field('content') ? '<h4>'. get_field('content') .'</h4>' : '';
        break;

    case 'image':
        $bgimage = get_field('bgimage');
        $style   = 'style="color:'. $fontcolor .';background-image:url('. $bgimage['url'] .');"';
        $title   = get_field('title') ? '<h1>'. get_field('title') .'</h1>' : '';
        $content = get_field('content') ? '<h4>'. get_field('content') .'</h4>' : '';
        break;

    case 'img-only':
        $bgimage = get_field('bgimage');
        $height  = get_field('height');
        $height_style = $height && strpos( $height, '%') != false ? 'min-height:0; height:0; padding-bottom:'. $height : 'height:'. $height;
        $style   = 'style="background-image:url('. $bgimage['url'] .');'. $height_style .';"';
        break;

    case 'video':
        $bgcolor = get_field('bgcolor');
        $bgimage = get_field('bgimage');
        $height  = get_field('height');
        $height_style = $height && ( strpos( $height, '%') != false || strpos( $height, 'vw') != false || strpos( $height, 'vh') != false )? 'min-height:0; height:'. str_replace('%', 'vw', $height) : 'height:'. $height;
        $video   = get_field('video');
        $options = get_field('video_options');
        $align  .= in_array('autoplay', $options) ? ' autoplay' : '';
        $content = get_field('play') . fullscreen_video($video, $options);
        $title   = get_field('title') ? '<h5>'. get_field('title') .'</h5>' : '';
        $style   = 'style="background-image:url('. $bgimage['url'] .');background-color:'. $bgcolor .';color:'. $fontcolor .';'. $height_style .';"';
        break;
}

$mobile = wp_is_mobile() ? ' mobile' : '';

?>

<div id="<?php echo $id; ?>" class="section intro <?php echo $button_bg .' '. $type . $mobile; ?>" <?php echo $style; ?>>
    <div class="content-wrap <?php echo $align; ?>">
        <?php echo $title . $content; ?>
    </div>
</div>


<?php

?>