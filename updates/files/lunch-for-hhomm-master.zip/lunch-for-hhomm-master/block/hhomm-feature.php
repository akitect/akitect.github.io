<?php 
$id = $block['id'];
$display = get_field('display') ? get_field('display') : array();
$slides = get_field('slides') ? get_field('slides') : '';
$height = get_field('height') ? get_field('height') : '';
$max_height = get_field('maxheight') ? get_field('maxheight') : '';
$height_style = $height && ( strpos( $height, '%') != false || strpos( $height, 'vw') != false || strpos( $height, 'vh') != false ) ? 'style="min-height:0; height:'. str_replace('%', 'vw', $height) .';max-height:'. $max_height .'px;"' : 'style="height:'. $height .';max-height:'. $max_height .'px;"';

// 관리자에서는 스타일 제거 
$height_style = !is_admin() ? $height_style : '';

$settings = get_field('settings') ? get_field('settings') : '';
if ( $settings ) {
    $delay    = $settings['delay'];
    $speed    = $settings['speed'];
    $loop     = $settings['loop'] ? true : false;
    $effect   = $settings['effect'];
    $direction= $settings['direction'];
    $options  = $settings['options'] ? $settings['options'] : array();

    $data_options = 'data-delay="'. $delay .'"
                     data-speed="'. $speed .'"
                     data-loop="'. $loop .'"
                     data-effect="'. $effect .'" 
                     data-direction="'. $direction .'" 
                     data-options="'. implode($options, ',') .'"';

    $bgcolor   = $settings['bgcolor'] == 'transparent' ? '' : 'background-color:'. $settings['bgcolor'] .';';
    $fontcolor = 'color:'. $settings['fontcolor'] .';';

    $align  = $settings['align'];
    $margin = 'margin:'. $settings['margin'] .';';
    $padding= 'padding:'. $settings['padding'] .';';
    $width  = $settings['width'] ? 'max-width:'. $settings['width'] .'px;' : '';
    $height = $settings['height'] ? 'height:'. $settings['height'] .'px;' : '';
}
?>

<div id="<?php echo $id; ?>" class="section feature-slider" <?php echo $height_style; ?> <?php echo $data_options; ?>>
    
    <div class="swiper-wrapper">
        <?php 
        foreach ( $slides as $slide ) {

            $post_object = $slide['post'];
            $image = $slide['image'] ? $slide['image'] : get_the_post_thumbnail_url($post_object, 'full');
            $link  = $slide['link'] ? $slide['link'] : '#id-'. $post_object->ID;
            $target= $slide['link'] ? 'target="_blank"' : '';

            $title = $slide['title'] ? $slide['title'] : $post_object->post_title;
            $title = in_array('title', $display) !== false ? $title : '';
            
            $desc  = $slide['desc'] ? $slide['desc'] : trim(strip_tags(wp_trim_words($post_object->post_content, 25, '...')));
            $desc  = in_array('desc', $display) !== false ? $desc : '';

            if ( in_array('link', $display) !== false ) {

                echo '<a href="'. $link .'" class="swiper-slide" style="background-image:url('. $image .');"'. $target .'>
                        <span class="text-box '. $align .'" style="'. $width . $height . $margin . $padding . $bgcolor . $fontcolor .'"><h4>'. $title .'</h4><span>'. $desc .'</span></span>
                      </a>';

            } else {

                echo '<div class="swiper-slide" style="background-image:url('. $image .');">
                        <span class="text-box '. $align .'" style="'. $width . $height . $margin . $padding . $bgcolor . $fontcolor .'"><h4>'. $title .'</h4><span>'. $desc .'</span></span>
                      </div>';

            }
            
        }
        ?>
    </div>
    
    <?php if ( in_array('pagination', $options) !== false ) { 
        echo '<div class="swiper-pagination"></div>';
    }?>

    <?php if ( in_array('navigation', $options) !== false ) { 
        echo '<div class="navigation-button-next swiper-navigation-button"><i class="icon-nav01-right"></i></div>
              <div class="navigation-button-prev swiper-navigation-button"><i class="icon-nav01-left"></i></div>';
    }?>

</div>