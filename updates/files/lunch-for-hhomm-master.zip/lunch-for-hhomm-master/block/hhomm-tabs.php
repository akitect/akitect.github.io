<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');
$bgimage   = get_field('bgimage') ? get_field('bgimage')['url'] : '';
$button_bg = $fontcolor == "#ffffff" ? 'button-bg-transparent' : '';
$style     = 'style="color:'. $fontcolor .';background-image:url('. $bgimage .');border-color:'. $fontcolor .';background-color:'. $bgcolor .';"';

$title = get_field('title') ? get_field('title') : '';
$type  = get_field('type');
$tabs  = get_field('tabs');
$tabs_length = count($tabs);

$count = 0;
$tab_titles = '';
$tab_contents = '';

foreach( $tabs as $tab ) {
    $count++;
    $first_selected = $count == 1 ? 'selected' : '';
    $tab_titles    .= '<li id="tab-'. $count .'" class="'. $first_selected .'"><span>'. $tab['title'] .'</span></li>';

    switch ( $tab['type'] ) {
        case 'default' : 
            $tab_content = apply_filters('the_content', $tab['content']);
            break;
        case 'list' :
            $items = '';
            foreach ( $tab['list'] as $item ) {
                $items .= '<li><label>'. $item['label'] .'</label>'. $item['content'] .'</li>';
            }
            $tab_content = '<ul class="list">'. $items .'</ul>';
            break;
    }
    
    switch ( $type ) {
        case 'tab' :
            $tab_contents .= '<div id="content-'. $count .'" class="'. $first_selected .'">'. $tab_content .'</div>';
            break;
        case 'accordion' :
            $tab_contents .= '<h2 class="title '. $first_selected .'">'. $tab['title'] .'</h2><div class="content-body '. $first_selected .'">'. $tab_content .'</div>';
            break;
        case 'card' : 
            $card_link = $tab['link'] ? ' data-target="link" data-link="'. $tab['link'] .'"' : 'data-target="popup"';
            $tab_contents .= '<div class="card-content selected"><h2 class="title">'. $tab['title'] .'</h2><div class="content-body">'. $tab_content .'</div><button'. $card_link .'></button></div>';
            break;
        case 'normal' :
            $tab_contents .= '<h2 class="title">'. $tab['title'] .'</h2><div class="content-body">'. $tab_content .'</div>';
            break;
    }
    
}

$tab_buttons = $type == 'tab' ? '<ul class="tabs tabs-'. $count .'">'. $tab_titles .'</ul>' : '';
?>

<div id="<?php echo $id; ?>" class="section <?php echo $type .' '. $button_bg; ?>" <?php echo $style; ?>>
    
    <div class="section-header">
        <span>
            <?php 
                $icon = get_page_template_slug() == false ? '<i class="'. get_field('icon') .'"></i>' : '';
                echo $icon . $title;
            ?>
        </span>
    </div>
    <div class="tab-wrap tabs-<?php echo $tabs_length; ?>">
        <?php echo $tab_buttons; ?>
        <div class="tab-content content-wrap">
            <?php echo $tab_contents; ?>
        </div>
    </div>

</div>