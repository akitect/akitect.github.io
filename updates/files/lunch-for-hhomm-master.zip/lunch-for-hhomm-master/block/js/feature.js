(function($) {

    $('.feature-slider').each( function(index, item) {

        var $this = $(item);
        $this.addClass('feature-slider-' + index);

        /* 표제 슬라이드 설정 */
        var feature_swiper = new Swiper('.feature-slider-' + index, {
            autoplay: {
                delay: Number($(item).attr('data-delay')),
            },
            loop: $(item).attr('data-loop'),
            effect: $(item).attr('data-effect'),
            direction: $(item).attr('data-direction'),
            speed: Number($(item).attr('data-speed')),
            spaceBetween: 0,
            navigation: {
                nextEl: '.navigation-button-next',
                prevEl: '.navigation-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                type: 'bullets',
                clickable: true,
            },
        });

    });

}(jQuery));