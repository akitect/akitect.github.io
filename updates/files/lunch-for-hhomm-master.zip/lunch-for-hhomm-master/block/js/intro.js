(function($) {

    /* intro 비디오 설정 */
    $('.section.intro.video i').click(function(){
        $(this).fadeOut(600);
        var iframe = $(this).parents('.section.video').find('iframe.fullscreen');
        var src = iframe.attr('src');
        src = src.indexOf('autoplay=') > -1 ? src.replace('autoplay=0', 'autoplay=1') : src + '&autoplay=1';
        iframe.attr('src', src).addClass('play');
    });

}(jQuery));