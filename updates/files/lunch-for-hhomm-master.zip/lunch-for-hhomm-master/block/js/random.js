(function($) {

    $('button[data-target=link]').click( function(){
        var url = $(this).attr('data-link');
        location.href = url;
    });

}(jQuery));