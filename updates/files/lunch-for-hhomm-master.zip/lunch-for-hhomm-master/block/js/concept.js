(function($) {

    var concept_swiper = new Swiper('.concept-slide', {
        paginationClickable: true,
        pagination: '.pagination',
        prevButton: '.button-prev',
        nextButton: '.button-next',
        paginationType: 'fraction',
        onSlideChangeEnd: function(swipe) {
            /* 슬라이드를 터치로 전환시 슬라이드 내용 업데이트 */
            var content = swipe.slides.parents('.card-content').find('.swiper-slide-active .description').html();
            swipe.slides.parents('.card-content').find('.concept-content .description').html(content);
        }
    });

    $('.concept-nav').click(function(){
        /* 슬라이드 전환 */
        var direction = $(this).hasClass('concept-prev') ? 'prev' : 'next';
        $(this).parents('.concept-container').find('.button-' + direction).click();

        /* 페이지 번호 추출 */
        var fraction = $(this).parents('.concept-container').find('.pagination').text();
        $(this).parents('.concept-content').find('.page-number').text(fraction);

        /* 슬라이드 텍스트 전환 */
        var current_content = $(this).parents('.concept-container').find('.swiper-slide-active').children('.description').html();
        $(this).parents('.concept-container').find('.concept-content .description').html(current_content);
    });
    
}(jQuery));