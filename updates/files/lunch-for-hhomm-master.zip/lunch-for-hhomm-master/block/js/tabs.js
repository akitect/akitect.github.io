(function($) {

    /* tab 설정 */
    $('.tabs li').click( function(){
        var selected = $(this).attr('ID').replace('tab', 'content');
        $('.tabs li.selected, .tab-content div.selected').removeClass('selected');
        $(this).addClass('selected');
        $('.tab-content #' + selected).addClass('selected');
    });  

    /* accordion 설정 */
    $('.accordion h2.title').click( function(){
        $(this).addClass('selected').next('div').addClass('show').slideDown(300);
        setTimeout( function(){
            $('.tab-content div.show').attr('class', 'selected');
        }, 300);
    });

    /* card 설정 */
    $('.section.card').on('click', 'button[data-target=link]', function(){
        var url = $(this).attr('data-link');
        if ( url.indexOf('http') > -1 ) {
            window.open(url, '_blank');
        } else {
            window.location.href = url;
        }
    });

}(jQuery));