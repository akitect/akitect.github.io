(function($) {

    /* 로딩 지연 */
    // $(window).load( function(){
    //     $('.section.post-index .content-wrap').slideDown(400);
    //     setTimeout(function(){
    //         $('.section.post-index').removeClass('loading');
    //     }, 400);
    // });

    /* 페이지내 삽입 설정 */
    $('.section').on('click', 'a[target=embed]', function(e){
        
        e.preventDefault();

        var permalink = $(this).attr('href');
        var template  = $(this).attr('data-template');
        var post_id   = $(this).attr('data-id');
        
        if ( !$(this).hasClass('current') ) {

            $(this).parents('.post-set').addClass('open');
            
            $.ajax({
                type: 'POST',
                url: permalink,
                data : { template : template },
                dataType: 'html',
                success: function( data, dataType ) {
                    
                    var post_id = $(data).find('#content').attr('data-post-id');
                    var embed_content = $(data).find('#content').html();
                    $('.post-set.open').append('<div class="embed-content" id="id-' + post_id + '">' + embed_content + '</div>').removeClass('open');
                    
                    var post_top = $('#id-' + post_id).offset().top - $('#navigation').height() - 30;
                    $('html, body').animate({scrollTop: post_top}, 400);
        
                }
            });

            $(this).addClass('current');

        } else {

            var post_top = $('#' + post_id).offset().top - $('#navigation').height() - 30;
            $('html, body').animate({scrollTop: post_top}, 400);

        }        
        
    });

    /* history 내용 열기 */
    $('.post-index').on('click', '.post-set.close', function(){
        $(this).removeClass('close');
    });


    /* Load More 버튼 설정 */
    $('.post-index').on('click', 'button.load-more', function(){

        var section_id = $(this).parents('.section').attr('ID');
        var next_page_no = $(this).attr('data-page-no');

        switch ( next_page_no ) {

            case 'all' : 

                $('#' + section_id).find('.content-wrap').children(':not(button)').slideDown(400);
                $('#' + section_id).find('button.load-more').fadeOut(400);

                break;

            default : 

                var posts_per_page = Number($(this).attr('data-posts-per-page'));
                var next_page = window.location.href + 'page/' + next_page_no;
                var new_page_no = Number(next_page_no) + 1;
                $(this).attr('data-page-no', new_page_no);
        
                $.ajax({
                    type: 'POST',
                    url: next_page,
                    dataType: 'html',
                    success: function(html) {
        
                        var posts = $(html).find('#' + section_id).find('.content-wrap').children(':not(button)');
        
                        $('#' + section_id).find('button.load-more').before(posts.css('display', 'block').hide());
                        $('#' + section_id).find('.content-wrap').children(':not(button)').slideDown(400);
                        
                        if ( posts.length < posts_per_page ) {
                            $('#' + section_id).find('button.load-more').fadeOut(400);
                        }
        
                    }
                });

                break;
        }

    });

}(jQuery));