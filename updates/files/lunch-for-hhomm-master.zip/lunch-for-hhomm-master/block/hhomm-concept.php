<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');

$title     = get_field('title');
$slides    = get_field('slides');
?>

<div id="<?php echo $id; ?>" class="section">
    <div class="card-content max-width-1200">
        <h2><span></span><?php echo $title; ?></span></h2>

        <div class="concept-container">

            <div class="concept-slide swiper-container">
                <div class="swiper-wrapper">

                <?php
                $count = 0;
                foreach( $slides as $slide ) {

                    $count++;
                    $desc = '<h4>'. $slide['title'] .'</h4>'. $slide['description'];
                    if( $count == 1 ) { $first_content = $desc; }
                    echo
                    '<div class="swiper-slide" style="background-image:url('. $slide['sizes']['large'] .');">
                        <div class="description">'. $desc .'</div>
                    </div>';
                }
                ?>

                </div>
                <div class="pagination"></div>
                <div class="button-prev"></div>
                <div class="button-next"></div>
            </div>

            <div class="concept-content">

                <div class="concept-pagination">
                <div class="concept-prev concept-nav"><i></i></div>
                <div class="concept-next concept-nav"><i></i></div>
                <div class="page-number">1 / <?php echo $count; ?></div>
                </div>
                <div class="description">
                <!-- 첫번째 컨셉 슬라이드 내용 -->
                <?php echo $first_content; ?>
                </div>
            </div>

        </div>

    </div>
</div>


<!-- style -->
<style type="text/css">
    #<?php echo $id; ?> {
        color:<?php echo $fontcolor; ?>;
        background-color:<?php echo $bgcolor; ?>; 
    }
    #<?php echo $id; ?> .card-content h2 {
        border-bottom: 4px solid <?php echo $fontcolor; ?>; 
    }
</style>