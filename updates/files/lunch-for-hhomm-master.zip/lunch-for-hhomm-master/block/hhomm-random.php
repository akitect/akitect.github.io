<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');
$bgimage   = get_field('bgimage');
$button_bg = $fontcolor == "#ffffff" ? 'button-bg-transparent' : '';
$style     = $bgimage ? 'style="color:'. $fontcolor .';background-image:url('. $bgimage['url'] .');"' : 'style="color:'. $fontcolor .';background-color:'. $bgcolor .';"';


$post_bgcolor   = get_field('post_bgcolor');
$post_fontcolor = get_field('post_fontcolor');
$post_style = 'style="color:'. $post_fontcolor.';background-color:'. $post_bgcolor .';"';

$title     = get_field('title') ? get_field('title') : '';
$post_type = get_field('post_type');
$length    = get_field('length');
$display   = get_field('display') ? get_field('display') : array();
?>

<div id="<?php echo $id; ?>" class="section random-posts posts-<?php echo $length; ?> <?php echo $button_bg; ?>" <?php echo $style; ?>>
    <div class="section-header">
        <span>
            <?php 
                $icon = get_page_template_slug() == false ? '<i class="'. get_field('icon') .'"></i>' : '';
                echo $icon . $title;
            ?>
        </span>
    </div>
    <div class="content-wrap">
        <?php
            $args = array(
                'numberposts'      => $length,
                'orderby'          => 'rand',
                'post_type'        => $post_type,
            );
            $random_posts = get_posts($args);
            foreach( $random_posts as $random ) {

                $title      = in_array('title', $display)      ? '<h4>'. $random->post_title .'</h4>' : '';
                $excerpt    = in_array('excerpt', $display)    ? '<div class="excerpt">'. get_the_excerpt($random) .'</div>' : '';
                $thumbnail  = in_array('thumbnail', $display)  ? '<div class="thumbnail" style="background-image:url('. get_the_post_thumbnail_url($random, 'large') .');"></div>' : '';
                $link       = in_array('link', $display)       ? true : false;

                if ( $link ) {
                    echo '<a class="random-post" href="'. get_the_permalink($random) .'" '. $post_style .'>'. $thumbnail . $title . $excerpt .'</a>';
                } else {

                    $button_color   = get_field('button_color');
                    $button_fontcolor = get_field('button_fontcolor');
                    $button_style = 'style="color:'. $button_fontcolor.';background-color:'. $button_color .';"';
                    
                    $button = in_array('button', $display) ? '<button data-target="link" data-link="'. get_the_permalink($random) .'" '. $button_style .'></button>' : '';

                    echo '<div class="random-post" '. $post_style .'>'. $thumbnail . $title . $excerpt . $button .'</div>';
                }

            }
        ?>
    </div>
</div>