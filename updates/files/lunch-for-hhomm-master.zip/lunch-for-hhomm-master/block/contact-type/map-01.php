<?php if ( $map ) : ?>
    <div class="acf-map" <?php echo $marker_icon .' '. $marker_size .' '. $map_options; ?> data-zoom="<?php the_field('map_zoom','option'); ?>">
        <div class="marker" data-lat="<?php echo $map['lat']; ?>" data-lng="<?php echo $map['lng']; ?>"></div>
    </div>
<?php endif; ?>

<div class="content-wrap">
    <?php echo $content; ?>
</div>