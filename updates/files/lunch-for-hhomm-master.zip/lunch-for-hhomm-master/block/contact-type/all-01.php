<div class="content-wrap">
    <?php echo $content; ?>
</div>

<?php if ( $map ) : ?>
    <div class="acf-map" <?php echo $marker_icon .' '. $marker_size .' '. $map_options; ?>>
        <div class="marker" data-lat="<?php echo $map['lat']; ?>" data-lng="<?php echo $map['lng']; ?>"></div>
    </div>
<?php endif; ?>

<?php echo $button . $popupform; ?>