<?php 
$id = $block['id'];
$fontcolor = get_field('fontcolor');
$bgcolor   = get_field('bgcolor');
$bgimage   = get_field('bgimage');
$button_bg = $fontcolor == "#ffffff" ? 'button-bg-transparent' : '';
$style     = $bgimage ? 'style="color:'. $fontcolor .';background-image:url('. $bgimage['url'] .');"' : 'style="color:'. $fontcolor .';background-color:'. $bgcolor .';"';

$title   = get_field('title') ? get_field('title') : '';
$content = get_field('content') ? apply_filters('the_content', get_field('content', false, false)) : '';
?>

<div id="<?php echo $id; ?>" class="section about <?php echo $button_bg; ?>" <?php echo $style; ?>>
    <div class="section-header">
        <?php 
            $icon = get_page_template_slug() == false ? '<i class="'. get_field('icon') .'"></i>' : '';
            echo $icon . $title;
        ?>
    </div>
    <div class="content-wrap">
        <?php echo $content; ?>
    </div>
</div>