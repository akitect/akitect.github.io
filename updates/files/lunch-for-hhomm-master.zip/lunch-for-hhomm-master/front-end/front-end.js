(function($) {
  $(document).ready(function () {

    $('span.linkHHOMM').click( function () {
      window.open('http://hhomm.com', '_blank');
    });

    $('body.parking #container').click( function(){
      window.open('mailto:office@hhomm.com', '_self');
    });

  });
}(jQuery));
