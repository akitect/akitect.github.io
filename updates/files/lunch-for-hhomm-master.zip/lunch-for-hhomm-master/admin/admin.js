(function($) {
  $(document).ready(function () {

    /* 업데이트 버튼 설정 */
    $(window).scroll( function() {

      var window_top = $(window).scrollTop();
      if ( window_top > $(window).height() ) {
        $('#hhomm-edit-buttons').addClass('show');
      } else {
        $('#hhomm-edit-buttons').removeClass('show');
      }

    });

    $('a#save-post').click( function() {
      $('#publishing-action input.button-primary').click();
    });
    

  });
}(jQuery));
